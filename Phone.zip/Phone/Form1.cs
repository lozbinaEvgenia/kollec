﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Phone
{
    public partial class Form1 : Form
    {
        Hashtable phoneBook;
        public Form1()
        {
            InitializeComponent();
            phoneBook = new Hashtable();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
                string lastName = txtLastName.Text;
                string phoneNumber = txtPhoneNumber.Text;

            if (phoneBook.ContainsKey(lastName))
            {
                MessageBox.Show("Контакт с такой фамилией уже существует!");
            }
            else
            {
                phoneBook.Add(lastName, phoneNumber);
                MessageBox.Show("Контакт успешно добавлен!");
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchQuery = txtSearch.Text;

            if (phoneBook.ContainsKey(searchQuery))
            {
                string phoneNumber = (string)phoneBook[searchQuery];
                MessageBox.Show($"Номер телефона для фамилии '{searchQuery}': {phoneNumber}");
            }
            else
            {
                MessageBox.Show($"Контакт с фамилией '{searchQuery}' не найден!");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string lastName = txtLastName.Text;

            if (phoneBook.ContainsKey(lastName))
            {
                phoneBook.Remove(lastName);
                MessageBox.Show("Контакт успешно удален!");
            }
            else
            {
                MessageBox.Show("Контакт с такой фамилией не найден!");
            }
        }

        private void btnShowContacts_Click(object sender, EventArgs e)
        {
            string contactsString = "Список контактов:\n";

            foreach (DictionaryEntry entry in phoneBook)
            {
                string lastName = (string)entry.Key;
                string phoneNumber = (string)entry.Value;

                contactsString += $"Фамилия: {lastName}, Номер телефона: {phoneNumber}\n";
            }

            MessageBox.Show(contactsString, "Список контактов");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string phoneNumberSearch = txtPhoneNumberSearch.Text;
            string foundLastName = null;

            foreach (DictionaryEntry entry in phoneBook)
            {
                string lastName = (string)entry.Key;
                string phoneNumber = (string)entry.Value;

                if (phoneNumber == phoneNumberSearch)
                {
                    foundLastName = lastName;
                    break;
                }
            }

            if (foundLastName != null)
            {
                MessageBox.Show($"Фамилия для номера телефона '{phoneNumberSearch}': {foundLastName}");
            }
            else
            {
                MessageBox.Show($"Контакт с номером телефона '{phoneNumberSearch}' не найден!");
            }
        }
    }
}
